package com.example.myapplication;

import android.os.Bundle;
import android.app.Activity;
//import android.view.Menu;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class TableActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);

        TableLayout table = (TableLayout) findViewById(R.id.myTableLayout);
        for(int i=0; i<MainActivity.prekes.size(); i++)
        {
            TableRow row=new TableRow(this);
            /*String product = MainActivity.prekes.getName(i);
            double price = MainActivity.prekes.getPrice(i);
            int cal = MainActivity.prekes.getCal(i);*/
            TextView tvPrekes=new TextView(this);
            //tvPrekes.setText(""+name+" "+price+" "+cal);
            row.addView(tvPrekes);
            table.addView(row);
        }

    }
}
