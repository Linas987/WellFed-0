package com.example.myapplication;

import android.support.test.rule.ActivityTestRule;
import android.widget.TableLayout;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import static org.junit.Assert.*;

public class TableActivityTest {

    @Rule
    public ActivityTestRule<TableActivity> tActivityTestRule = new ActivityTestRule<TableActivity>(TableActivity.class);
    private TableActivity tActivity = null;

    @Before
    public void setUp() throws Exception {
        tActivity = tActivityTestRule.getActivity();
    }

    @Test
    public void onCreate() throws Exception {
        TableLayout table = (TableLayout) tActivity.findViewById(R.id.myTableLayout);
        assertNotNull(table);
    }

    @After
    public void tearDown() throws Exception {
        tActivity = null;
    }

}