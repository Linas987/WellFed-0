package com.example.myapplication;

import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.test.rule.ActivityTestRule;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.junit.Assert.*;

public class MenueActivityTest {

    @Rule
    public ActivityTestRule<MenueActivity> mActivityTestRule = new ActivityTestRule<MenueActivity>(MenueActivity.class);
    private MenueActivity mActivity = null;

    @Before
    public void setUp() throws Exception {
        mActivity = mActivityTestRule.getActivity();
    }

    @Test
    public void onCreate() throws Exception {
        Toolbar tool = (Toolbar) mActivity.findViewById(R.id.toolbar);
        CollapsingToolbarLayout toolLay = (CollapsingToolbarLayout) mActivity.findViewById(R.id.toolbar_layout);
        TextView table=(TextView) mActivity.findViewById(R.id.TableView);
        FloatingActionButton fab = (FloatingActionButton) mActivity.findViewById(R.id.fab);
        FloatingActionButton back = (FloatingActionButton) mActivity.findViewById(R.id.Back);
        assertNotNull(tool); assertNotNull(toolLay); assertNotNull(table); assertNotNull(fab); assertNotNull(back);
    }

    @After
    public void tearDown() throws Exception {
        mActivity = null;
    }

}