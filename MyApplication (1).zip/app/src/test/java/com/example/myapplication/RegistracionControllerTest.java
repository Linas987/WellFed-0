package com.example.myapplication;

import android.support.test.rule.ActivityTestRule;
import android.widget.Button;
import android.widget.EditText;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import static org.junit.Assert.*;

public class RegistracionControllerTest {

    @Rule
    public ActivityTestRule<RegistracionController> rControllerTestRule = new ActivityTestRule<RegistracionController>(RegistracionController.class);
    private RegistracionController rController = null;

    @Before
    public void setUp() throws Exception {
        rController = rControllerTestRule.getActivity();
    }

    @Test
    public void onCreate() throws Exception {
        Button back=(Button) rController.findViewById(R.id.Back);
        Button confirm=(Button) rController.findViewById(R.id.Confirm);
        EditText user=(EditText) rController.findViewById(R.id.Username);
        EditText pass=(EditText) rController.findViewById(R.id.Password);
        EditText email=(EditText) rController.findViewById(R.id.Email);
        EditText heigth=(EditText) rController.findViewById(R.id.Heigth);
        EditText weigth=(EditText) rController.findViewById(R.id.Weigth);
        EditText age=(EditText) rController.findViewById(R.id.Age);
        assertNotNull(back); assertNotNull(confirm); assertNotNull(user); assertNotNull(pass);
        assertNotNull(email); assertNotNull(heigth); assertNotNull(weigth); assertNotNull(age);
    }

    @After
    public void tearDown() throws Exception {
        rController = null;
    }

}